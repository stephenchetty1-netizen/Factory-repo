"""
run_pipeline.py
The full autonomous loop: generate a product -> write its listing -> publish
to Gumroad -> log the result. This is the single script your scheduler
(cron or Railway) should run periodically.

Usage:
    python3 run_pipeline.py            # generate + publish 1 product
    python3 run_pipeline.py --count 5  # generate + publish 5 products
    python3 run_pipeline.py --dry-run  # generate + write listing, skip upload
"""
import argparse
import json
import os
import sys
import traceback
from datetime import datetime

from generate_product import generate_one
from write_listing import write_listing

LOG_PATH = os.path.join(os.path.dirname(__file__), "pipeline_log.jsonl")


def log(entry):
    entry["timestamp"] = datetime.now().isoformat()
    with open(LOG_PATH, "a") as f:
        f.write(json.dumps(entry) + "\n")
    print(json.dumps(entry, indent=2))


PUBLISHERS = {}

try:
    from publish_gumroad import publish as _publish_gumroad
    PUBLISHERS["gumroad"] = _publish_gumroad
except ImportError:
    pass

try:
    from publish_stripe import publish as _publish_stripe
    PUBLISHERS["stripe"] = _publish_stripe
except ImportError:
    pass


def run_once(platforms, dry_run=False):
    meta = generate_one()
    listing = write_listing(meta)

    if dry_run:
        log({"status": "dry_run", "meta": meta, "listing": listing})
        return

    for platform in platforms:
        publish_fn = PUBLISHERS.get(platform)
        if publish_fn is None:
            log({"status": "error", "platform": platform, "error": f"Unknown platform: {platform}"})
            continue
        try:
            result = publish_fn(meta, listing)
            log({"status": "published", "platform": platform, "meta": meta, "listing": listing, "result": result})
        except Exception as e:
            log({
                "status": "error",
                "platform": platform,
                "meta": meta,
                "listing": listing,
                "error": str(e),
                "traceback": traceback.format_exc(),
            })


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--count", type=int, default=1)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument(
        "--platforms",
        type=str,
        default="gumroad,stripe",
        help="Comma-separated list, e.g. 'gumroad' or 'gumroad,stripe'",
    )
    args = parser.parse_args()
    platforms = [p.strip() for p in args.platforms.split(",") if p.strip()]

    for _ in range(args.count):
        run_once(platforms, dry_run=args.dry_run)


if __name__ == "__main__":
    main()
