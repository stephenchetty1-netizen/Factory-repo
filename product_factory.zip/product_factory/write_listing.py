"""
write_listing.py
Turns product metadata into store-ready listing copy (title, description,
tags, price). Template-based so it runs with zero API cost/dependencies.
Swap in a Claude API call here later if you want richer, more varied copy.
"""
import random

DESCRIPTIONS = {
    "weekly_planner": (
        "Stay on top of your week with this clean, undated weekly planner. "
        "Print it out and reuse every week, or fill it in digitally. Includes "
        "space for daily to-dos plus a Sunday notes section for reflection and planning ahead.\n\n"
        "\u2022 Undated \u2014 start any week, any month\n"
        "\u2022 Print at home (Letter size, 8.5x11)\n"
        "\u2022 Instant digital download (PDF)\n"
        "\u2022 Personal use license"
    ),
    "habit_tracker": (
        "Build better habits and see your progress at a glance with this monthly "
        "habit tracker. Track up to 10 habits across a full month in one simple grid.\n\n"
        "\u2022 Fits any month, any habits\n"
        "\u2022 Print at home (Letter size, 8.5x11)\n"
        "\u2022 Instant digital download (PDF)\n"
        "\u2022 Personal use license"
    ),
    "budget_tracker": (
        "Take control of your money with this simple monthly budget tracker. "
        "Compare budgeted vs. actual spending across common categories and spot where "
        "your money is really going.\n\n"
        "\u2022 12 built-in categories + totals row\n"
        "\u2022 Print at home (Letter size, 8.5x11)\n"
        "\u2022 Instant digital download (PDF)\n"
        "\u2022 Personal use license"
    ),
    "daily_checklist": (
        "Plan focused, productive days with this daily checklist. Set your top 3 "
        "priorities, block out your schedule hour by hour, and capture wins and notes "
        "at the end of the day.\n\n"
        "\u2022 Top-3 priority section + hourly schedule\n"
        "\u2022 Print at home (Letter size, 8.5x11)\n"
        "\u2022 Instant digital download (PDF)\n"
        "\u2022 Personal use license"
    ),
}

TAGS = {
    "weekly_planner": ["planner", "weekly planner", "printable planner", "undated planner", "productivity"],
    "habit_tracker": ["habit tracker", "printable tracker", "monthly habit tracker", "self improvement", "goals"],
    "budget_tracker": ["budget tracker", "budget planner", "finance printable", "money tracker", "save money"],
    "daily_checklist": ["daily planner", "checklist printable", "to do list", "productivity planner", "daily schedule"],
}

PRICE_RANGE = {
    "weekly_planner": (2.50, 4.50),
    "habit_tracker": (2.00, 4.00),
    "budget_tracker": (3.00, 5.50),
    "daily_checklist": (2.00, 3.50),
}


def write_listing(meta):
    ptype = meta["type"]
    theme = meta["theme"]
    title = f"{meta['display_name']} \u2014 {theme} Printable (Instant Download PDF)"
    description = DESCRIPTIONS[ptype]
    tags = TAGS[ptype]
    lo, hi = PRICE_RANGE[ptype]
    price = round(random.uniform(lo, hi), 2)

    listing = {
        "title": title,
        "description": description,
        "tags": tags,
        "price_usd": price,
    }
    return listing


if __name__ == "__main__":
    import json
    from generate_product import generate_one
    meta = generate_one()
    listing = write_listing(meta)
    print(json.dumps({"meta": meta, "listing": listing}, indent=2))
