"""
publish_stripe.py
Creates a Stripe Product + Price + Payment Link for a generated product, and
registers it in the local storefront's products.json so the storefront site
picks it up automatically.

Requires an environment variable:
    STRIPE_SECRET_KEY

Get one at: https://dashboard.stripe.com/apikeys (instant, self-serve,
no approval wait). Use a "restricted key" with write access to
Products, Prices, and Payment Links if you want to scope it tightly.
"""
import os
import json
import shutil
import requests

STRIPE_API = "https://api.stripe.com/v1"
STOREFRONT_DIR = os.path.join(os.path.dirname(__file__), "storefront")
FILES_DIR = os.path.join(STOREFRONT_DIR, "files")
PRODUCTS_JSON = os.path.join(STOREFRONT_DIR, "products.json")

os.makedirs(FILES_DIR, exist_ok=True)


def _auth():
    key = os.environ.get("STRIPE_SECRET_KEY")
    if not key:
        raise RuntimeError(
            "STRIPE_SECRET_KEY is not set. Get one at "
            "https://dashboard.stripe.com/apikeys and set it as an "
            "environment variable before running this script."
        )
    return (key, "")


def _load_products():
    if os.path.exists(PRODUCTS_JSON):
        with open(PRODUCTS_JSON) as f:
            return json.load(f)
    return []


def _save_products(products):
    with open(PRODUCTS_JSON, "w") as f:
        json.dump(products, f, indent=2)


def publish(meta, listing):
    auth = _auth()

    # 1. Create the Product
    resp = requests.post(
        f"{STRIPE_API}/products",
        auth=auth,
        data={
            "name": listing["title"],
            "description": listing["description"],
        },
        timeout=30,
    )
    resp.raise_for_status()
    product = resp.json()

    # 2. Create the Price (Stripe wants amounts in cents)
    resp = requests.post(
        f"{STRIPE_API}/prices",
        auth=auth,
        data={
            "product": product["id"],
            "unit_amount": int(round(listing["price_usd"] * 100)),
            "currency": "usd",
        },
        timeout=30,
    )
    resp.raise_for_status()
    price = resp.json()

    # 3. Create a Payment Link (a hosted, shareable checkout page - this IS
    #    the "post it somewhere buyers can find it" step; no custom site
    #    required for checkout itself, though we also list it on our own
    #    storefront page below for browsability).
    resp = requests.post(
        f"{STRIPE_API}/payment_links",
        auth=auth,
        data={
            "line_items[0][price]": price["id"],
            "line_items[0][quantity]": 1,
            "after_completion[type]": "redirect",
            "after_completion[redirect][url]":
                f"{os.environ.get('STOREFRONT_BASE_URL', 'http://localhost:5000')}"
                f"/download/{meta['filename']}?session_id={{CHECKOUT_SESSION_ID}}",
        },
        timeout=30,
    )
    resp.raise_for_status()
    payment_link = resp.json()

    # 4. Copy the actual file into the storefront's protected files folder
    dest = os.path.join(FILES_DIR, meta["filename"])
    shutil.copy(meta["file_path"], dest)

    # 5. Register it in products.json so the storefront homepage lists it
    products = _load_products()
    products.append({
        "title": listing["title"],
        "description": listing["description"],
        "price_usd": listing["price_usd"],
        "filename": meta["filename"],
        "payment_link_url": payment_link["url"],
        "stripe_product_id": product["id"],
        "stripe_price_id": price["id"],
    })
    _save_products(products)

    return {
        "product_id": product["id"],
        "price_id": price["id"],
        "payment_link": payment_link["url"],
    }


if __name__ == "__main__":
    from generate_product import generate_one
    from write_listing import write_listing

    meta = generate_one()
    listing = write_listing(meta)
    result = publish(meta, listing)
    print(json.dumps(result, indent=2))
