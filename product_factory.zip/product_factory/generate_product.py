"""
generate_product.py
Generates a printable digital PDF product (planner / tracker / checklist)
using reportlab. Picks a random template + color theme each run so that
repeated runs of the pipeline produce varied inventory.
"""
import random
import json
import os
from datetime import datetime
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor

OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "products")
os.makedirs(OUTPUT_DIR, exist_ok=True)

THEMES = [
    {"name": "Sage Minimal", "accent": "#7C9885", "text": "#2E2E2E", "light": "#F4F1EA"},
    {"name": "Terracotta Warm", "accent": "#C1694F", "text": "#2E2E2E", "light": "#FBF3EE"},
    {"name": "Navy Classic", "accent": "#2C3E50", "text": "#2E2E2E", "light": "#F0F2F5"},
    {"name": "Blush Soft", "accent": "#D88C9A", "text": "#2E2E2E", "light": "#FDF3F5"},
    {"name": "Charcoal Bold", "accent": "#3A3A3A", "text": "#1A1A1A", "light": "#F5F5F5"},
]

PRODUCT_TYPES = ["weekly_planner", "habit_tracker", "budget_tracker", "daily_checklist"]

WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def _header(c, width, height, theme, title, subtitle=""):
    c.setFillColor(HexColor(theme["accent"]))
    c.rect(0, height - 1.1 * inch, width, 1.1 * inch, fill=1, stroke=0)
    c.setFillColor(HexColor("#FFFFFF"))
    c.setFont("Helvetica-Bold", 22)
    c.drawString(0.6 * inch, height - 0.7 * inch, title)
    if subtitle:
        c.setFont("Helvetica", 11)
        c.drawString(0.6 * inch, height - 0.95 * inch, subtitle)


def _footer(c, width, theme, brand):
    c.setFillColor(HexColor(theme["text"]))
    c.setFont("Helvetica", 8)
    c.drawCentredString(width / 2, 0.4 * inch, brand)


def make_weekly_planner(path, theme, brand):
    c = canvas.Canvas(path, pagesize=letter)
    width, height = letter
    _header(c, width, height, theme, "Weekly Planner", "Undated \u2014 use any week")
    top = height - 1.5 * inch
    col_w = (width - 1.2 * inch) / 2
    row_h = 2.3 * inch
    for i, day in enumerate(WEEKDAYS[:6]):
        col = i % 2
        row = i // 2
        x = 0.6 * inch + col * col_w
        y = top - row * row_h
        c.setFillColor(HexColor(theme["light"]))
        c.roundRect(x, y - row_h + 0.3 * inch, col_w - 0.2 * inch, row_h - 0.3 * inch, 6, fill=1, stroke=0)
        c.setFillColor(HexColor(theme["accent"]))
        c.setFont("Helvetica-Bold", 13)
        c.drawString(x + 0.15 * inch, y - 0.05 * inch, day)
        c.setStrokeColor(HexColor(theme["accent"]))
        c.setFillColor(HexColor(theme["text"]))
        c.setFont("Helvetica", 9)
        for line in range(5):
            ly = y - 0.4 * inch - line * 0.32 * inch
            c.line(x + 0.15 * inch, ly, x + col_w - 0.35 * inch, ly)
    # Sunday full-width note row
    x = 0.6 * inch
    y = top - 3 * row_h
    c.setFillColor(HexColor(theme["light"]))
    c.roundRect(x, y - 0.9 * inch, width - 1.2 * inch, 0.9 * inch, 6, fill=1, stroke=0)
    c.setFillColor(HexColor(theme["accent"]))
    c.setFont("Helvetica-Bold", 13)
    c.drawString(x + 0.15 * inch, y - 0.2 * inch, "Sunday / Notes")
    _footer(c, width, theme, brand)
    c.save()
    return "Weekly Planner"


def make_habit_tracker(path, theme, brand):
    c = canvas.Canvas(path, pagesize=letter)
    width, height = letter
    _header(c, width, height, theme, "Monthly Habit Tracker", "Track up to 10 habits, 31 days")
    habits_n = 10
    days_n = 31
    top = height - 1.6 * inch
    left = 0.6 * inch
    grid_right = width - 0.5 * inch
    label_w = 1.8 * inch
    cell_w = (grid_right - left - label_w) / days_n
    cell_h = 0.28 * inch

    c.setFont("Helvetica", 6)
    for d in range(days_n):
        cx = left + label_w + d * cell_w + cell_w / 2
        c.setFillColor(HexColor(theme["text"]))
        c.drawCentredString(cx, top + 0.05 * inch, str(d + 1))

    for h in range(habits_n):
        y = top - h * cell_h
        c.setFillColor(HexColor(theme["text"]))
        c.setFont("Helvetica", 9)
        c.drawString(left, y - cell_h + 0.08 * inch, f"Habit {h + 1}: __________")
        c.setStrokeColor(HexColor(theme["accent"]))
        for d in range(days_n):
            x = left + label_w + d * cell_w
            c.rect(x, y - cell_h, cell_w, cell_h, fill=0, stroke=1)
    _footer(c, width, theme, brand)
    c.save()
    return "Monthly Habit Tracker"


def make_budget_tracker(path, theme, brand):
    c = canvas.Canvas(path, pagesize=letter)
    width, height = letter
    _header(c, width, height, theme, "Monthly Budget Tracker", "Income \u2014 Expenses \u2014 Savings")
    top = height - 1.6 * inch
    left = 0.6 * inch
    right = width - 0.6 * inch
    c.setFillColor(HexColor(theme["accent"]))
    c.setFont("Helvetica-Bold", 12)
    c.drawString(left, top, "Category")
    c.drawString(left + 3.2 * inch, top, "Budgeted")
    c.drawString(left + 4.6 * inch, top, "Actual")
    c.drawString(left + 5.8 * inch, top, "Diff")
    y = top - 0.15 * inch
    c.setStrokeColor(HexColor(theme["accent"]))
    c.line(left, y, right, y)

    categories = ["Rent/Mortgage", "Utilities", "Groceries", "Transportation",
                  "Insurance", "Subscriptions", "Entertainment", "Savings",
                  "Debt Payments", "Personal", "Misc", "Total"]
    row_h = 0.42 * inch
    for i, cat in enumerate(categories):
        ry = y - (i + 1) * row_h
        c.setFillColor(HexColor(theme["light"]) if i % 2 == 0 else HexColor("#FFFFFF"))
        c.rect(left, ry, right - left, row_h, fill=1, stroke=0)
        c.setFillColor(HexColor(theme["text"]))
        c.setFont("Helvetica-Bold" if cat == "Total" else "Helvetica", 10)
        c.drawString(left + 0.1 * inch, ry + 0.12 * inch, cat)
        for cx in [left + 3.2 * inch, left + 4.6 * inch, left + 5.8 * inch]:
            c.setStrokeColor(HexColor(theme["accent"]))
            c.line(cx, ry + 0.1 * inch, cx + 1.1 * inch, ry + 0.1 * inch)
    _footer(c, width, theme, brand)
    c.save()
    return "Monthly Budget Tracker"


def make_daily_checklist(path, theme, brand):
    c = canvas.Canvas(path, pagesize=letter)
    width, height = letter
    _header(c, width, height, theme, "Daily Productivity Checklist", "Top priorities, schedule & wins")
    left = 0.6 * inch
    top = height - 1.6 * inch

    c.setFillColor(HexColor(theme["accent"]))
    c.setFont("Helvetica-Bold", 12)
    c.drawString(left, top, "Top 3 Priorities")
    for i in range(3):
        y = top - 0.35 * inch - i * 0.35 * inch
        c.setStrokeColor(HexColor(theme["accent"]))
        c.rect(left, y - 0.15 * inch, 0.18 * inch, 0.18 * inch, fill=0, stroke=1)
        c.line(left + 0.3 * inch, y - 0.06 * inch, left + 3.6 * inch, y - 0.06 * inch)

    sched_top = top - 1.6 * inch
    c.setFillColor(HexColor(theme["accent"]))
    c.setFont("Helvetica-Bold", 12)
    c.drawString(left, sched_top, "Schedule")
    hours = [f"{h}:00" for h in list(range(7, 12)) + list(range(1, 9))]
    for i, hr in enumerate(hours):
        y = sched_top - 0.35 * inch - i * 0.32 * inch
        c.setFont("Helvetica", 8)
        c.setFillColor(HexColor(theme["text"]))
        c.drawString(left, y, hr)
        c.setStrokeColor(HexColor(theme["accent"]))
        c.line(left + 0.6 * inch, y + 0.02 * inch, left + 3.6 * inch, y + 0.02 * inch)

    notes_x = left + 4.2 * inch
    c.setFillColor(HexColor(theme["accent"]))
    c.setFont("Helvetica-Bold", 12)
    c.drawString(notes_x, sched_top, "Notes & Wins")
    c.setFillColor(HexColor(theme["light"]))
    c.roundRect(notes_x, sched_top - 4.5 * inch, width - 0.6 * inch - notes_x, 4.3 * inch, 6, fill=1, stroke=0)
    _footer(c, width, theme, brand)
    c.save()
    return "Daily Productivity Checklist"


BUILDERS = {
    "weekly_planner": make_weekly_planner,
    "habit_tracker": make_habit_tracker,
    "budget_tracker": make_budget_tracker,
    "daily_checklist": make_daily_checklist,
}


def generate_one(brand="Clarity Co. Studio"):
    ptype = random.choice(PRODUCT_TYPES)
    theme = random.choice(THEMES)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{ptype}_{theme['name'].replace(' ', '')}_{stamp}.pdf"
    path = os.path.join(OUTPUT_DIR, filename)
    display_name = BUILDERS[ptype](path, theme, brand)

    meta = {
        "type": ptype,
        "theme": theme["name"],
        "display_name": display_name,
        "file_path": path,
        "filename": filename,
        "generated_at": datetime.now().isoformat(),
    }
    meta_path = path.replace(".pdf", ".json")
    with open(meta_path, "w") as f:
        json.dump(meta, f, indent=2)
    return meta


if __name__ == "__main__":
    m = generate_one()
    print(json.dumps(m, indent=2))
