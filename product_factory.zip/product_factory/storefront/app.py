"""
app.py
The storefront web app. Two routes:
  GET /                                    -> homepage listing all products
  GET /download/<filename>?session_id=...  -> serves the file, but only
                                               after verifying the Stripe
                                               Checkout session was paid

Run locally:
    STRIPE_SECRET_KEY=sk_... python3 app.py

Deploy: this is a normal Flask app, deployable to Railway (or any host)
as a persistent web service, separate from the product-generation cron job.
"""
import os
import json
import requests
from flask import Flask, render_template, send_from_directory, abort, request

app = Flask(__name__)

BASE_DIR = os.path.dirname(__file__)
FILES_DIR = os.path.join(BASE_DIR, "files")
PRODUCTS_JSON = os.path.join(BASE_DIR, "products.json")
STRIPE_API = "https://api.stripe.com/v1"


def load_products():
    if os.path.exists(PRODUCTS_JSON):
        with open(PRODUCTS_JSON) as f:
            return json.load(f)
    return []


@app.route("/")
def home():
    products = load_products()
    return render_template("index.html", products=products)


@app.route("/download/<path:filename>")
def download(filename):
    session_id = request.args.get("session_id")
    if not session_id:
        abort(403, "Missing session_id")

    key = os.environ.get("STRIPE_SECRET_KEY")
    if not key:
        abort(500, "Server misconfigured: STRIPE_SECRET_KEY not set")

    resp = requests.get(
        f"{STRIPE_API}/checkout/sessions/{session_id}",
        auth=(key, ""),
        timeout=15,
    )
    if not resp.ok:
        abort(403, "Could not verify payment session")

    session = resp.json()
    if session.get("payment_status") != "paid":
        abort(403, "Payment not completed")

    file_path = os.path.join(FILES_DIR, filename)
    if not os.path.exists(file_path):
        abort(404, "File not found")

    return send_from_directory(FILES_DIR, filename, as_attachment=True)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
