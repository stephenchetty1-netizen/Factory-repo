# Digital Product Factory

A pipeline that generates printable PDF products (planners, trackers,
checklists), writes their store listing, and publishes them to Gumroad —
on a schedule, with no manual steps once it's set up.

## What it does each run
1. `generate_product.py` — builds a new printable PDF (random type + color theme)
2. `write_listing.py` — writes a title, description, tags, and price for it
3. `publish_gumroad.py` — uploads the file and creates a live Gumroad listing
4. `run_pipeline.py` — runs all three and logs the result to `pipeline_log.jsonl`

## One-time setup (you do this — takes ~5 minutes)

1. **Create a Gumroad account**: https://gumroad.com
2. **Get an access token**:
   - Go to https://app.gumroad.com/settings/advanced
   - Under "Applications", click "Create application"
   - Generate an access token for your own account
3. **Install dependencies**:
   ```bash
   pip install reportlab requests
   ```
4. **Set the token as an environment variable**:
   ```bash
   export GUMROAD_ACCESS_TOKEN="your_token_here"
   ```
5. **Test it** (dry run, no upload):
   ```bash
   python3 run_pipeline.py --dry-run
   ```
6. **Test a real publish** (creates one live $2–5 listing):
   ```bash
   python3 run_pipeline.py --count 1
   ```

## Making it fully autonomous

Pick one:

### Option A — Cron on your own machine (simplest, but only runs while your computer is on)
```bash
crontab -e
# add this line to run once a day at 9am:
0 9 * * * cd /path/to/product_factory && GUMROAD_ACCESS_TOKEN=your_token python3 run_pipeline.py --count 1 >> cron.log 2>&1
```

### Option B — Always-on cloud scheduler (recommended for true "set and forget")
Deploy this folder to Railway (or any host that supports scheduled jobs / cron):
1. Push this folder to a GitHub repo
2. Create a Railway project from that repo
3. Set `GUMROAD_ACCESS_TOKEN` in Railway's environment variables
4. Add a Cron Schedule trigger (Railway supports this natively) set to run
   `python3 run_pipeline.py --count 1` on whatever cadence you want (e.g. daily)

I can walk you through either setup interactively if you'd like — just say which one.

## Selling on your own Stripe storefront

This is a second, fully self-serve sales channel — no third-party approval,
live in minutes. It works like this: each product gets a real Stripe
Product + Price + Payment Link (a hosted checkout page), and also gets
listed on a simple storefront homepage (`storefront/app.py`) that you
control. After payment, the buyer is redirected to a download link that's
verified against Stripe before the file is served.

### One-time setup
1. Create a Stripe account: https://dashboard.stripe.com/register (instant)
2. Get a secret key: https://dashboard.stripe.com/apikeys
3. Set it as an environment variable:
   ```bash
   export STRIPE_SECRET_KEY="sk_live_..."
   ```
4. (Optional but recommended) also set your storefront's public URL once deployed:
   ```bash
   export STOREFRONT_BASE_URL="https://your-app.up.railway.app"
   ```

### Run the pipeline against Stripe only
```bash
python3 run_pipeline.py --count 1 --platforms stripe
```
Or both platforms at once (the default):
```bash
python3 run_pipeline.py --count 1 --platforms gumroad,stripe
```

### Deploy the storefront itself
The storefront lives in the `storefront/` subfolder with its own
`requirements.txt` and `railway.json`. When creating the Railway service,
set its **Root Directory** to `storefront` (Railway dashboard → service →
Settings → Root Directory) so it builds only that folder.

1. Push the whole `product_factory/` repo to GitHub
2. Create a Railway service from that repo, with Root Directory = `storefront`
3. Set `STRIPE_SECRET_KEY` in that service's environment variables
4. Railway will give you a public URL — that's your live storefront

Run the generator pipeline (Option A or B from above) so it writes new
entries into `storefront/products.json` and drops files into
`storefront/files/` — the storefront picks them up automatically, no restart needed.

## Extending to more platforms
- **Etsy**: requires an approved developer app; approval has been slow and
  inconsistent for many developers recently. Once you have API credentials,
  the same `publish_*.py` pattern applies — I can write `publish_etsy.py`
  when you have keys.
- **Shopify**: requires a paid store + private app credentials. Same pattern,
  fully self-serve once you're subscribed.
- **Lemon Squeezy / Payhip**: checked both — neither currently offers a
  public API for *creating new products*, only for checkout/orders/licensing.
  New listings have to be added by hand in their dashboards, so they don't
  fit a fully autonomous pipeline. Skip these for this use case.
- **Your own website (done)**: the Stripe storefront above is the most
  reliable "other platform" — zero approval process, fully scriptable.

## Important notes
- Prices are deliberately modest ($2–5) — printable-planner marketplaces are
  price-sensitive; you can edit `PRICE_RANGE` in `write_listing.py` to adjust.
- The listing copy is template-based (no API cost). If you want richer,
  more varied copy, this is a good place to plug in a Claude API call.
- Review your first several auto-published listings on Gumroad's dashboard
  to make sure they look right before letting it run unattended long-term.
- No system can guarantee sales — this automates the *listing* side, not demand.
  You'll still get more traction by occasionally promoting listings yourself
  (social posts, Pinterest, etc.).
