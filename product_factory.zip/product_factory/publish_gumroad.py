"""
publish_gumroad.py
Uploads a generated product file to Gumroad and creates a published listing.

Requires an environment variable:
    GUMROAD_ACCESS_TOKEN

Get one at: https://app.gumroad.com/settings/advanced -> "Applications" ->
create an application -> generate an access token for your own account.
(Takes about 2 minutes, no approval wait.)
"""
import os
import requests

GUMROAD_API = "https://api.gumroad.com/v2/products"


def publish(meta, listing):
    token = os.environ.get("GUMROAD_ACCESS_TOKEN")
    if not token:
        raise RuntimeError(
            "GUMROAD_ACCESS_TOKEN is not set. Create one at "
            "https://app.gumroad.com/settings/advanced and set it as an "
            "environment variable before running this script."
        )

    with open(meta["file_path"], "rb") as f:
        files = {"file": (meta["filename"], f, "application/pdf")}
        data = {
            "access_token": token,
            "name": listing["title"],
            "price": int(round(listing["price_usd"] * 100)),  # cents
            "description": listing["description"],
            "tags[]": listing["tags"],
            "published": "true",
        }
        resp = requests.post(GUMROAD_API, data=data, files=files, timeout=60)

    try:
        result = resp.json()
    except ValueError:
        raise RuntimeError(f"Gumroad returned a non-JSON response: {resp.text[:300]}")

    if not resp.ok or not result.get("success", False):
        raise RuntimeError(f"Gumroad publish failed: {result}")

    product = result["product"]
    return {
        "id": product.get("id"),
        "name": product.get("name"),
        "url": product.get("short_url"),
        "price": product.get("formatted_price"),
    }


if __name__ == "__main__":
    import json
    from generate_product import generate_one
    from write_listing import write_listing

    meta = generate_one()
    listing = write_listing(meta)
    published = publish(meta, listing)
    print(json.dumps(published, indent=2))
